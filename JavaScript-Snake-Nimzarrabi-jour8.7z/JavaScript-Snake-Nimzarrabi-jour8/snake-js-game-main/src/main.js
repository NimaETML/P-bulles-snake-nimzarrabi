/**
 * ETML
 * Auteur:          Nima Zarrabi
 * Date:            07.11.2023
 * Description:     Jeu Snake
 * 
 * Version          1.7.0
 * Date:            9.1.2024
 */

import { GameEngine } from "./GameEngine.js";

// commancement du jeu
GameEngine.gameInitiation();
GameEngine.startGame();


