/**
 * ETML
 * Auteur:          Nima Zarrabi
 * Date:            07.11.2023
 * Description:     Jeu Snake
 * 
 * Version          1.7.0
 * Date:            9.1.2024
 */

import { SnakeHead } from './GameEngine.js';
import { SquareSize } from './GameEngine.js';
import { Boardsize } from './GameEngine.js';

export let snakeList = []

export class Snake {


    constructor(id, x, y, directionX, directionY) {
        this.id = id;                       // Id du Snake
        this.x = x;                         //Position X du Snake
        this.y = y;                         //Position Y du Snake
        this.directionX = directionX;       // direction en X du Snake
        this.directionY = directionY;       // direction en Y du Snake
    }
    
    /**
     * Permet au Snake de changer de direction de fonction de touches presse
     * @param touche touche presse
     */
    static changeDirection(touche) {
        touche.preventDefault()
        if (touche.keyCode === 37 && SnakeHead.directionX == 0) SnakeHead.directionX = -1, SnakeHead.directionY = 0; // go left
        if (touche.keyCode === 38 && SnakeHead.directionY == 0) SnakeHead.directionY = -1, SnakeHead.directionX = 0; // go up
        if (touche.keyCode === 39 && SnakeHead.directionX == 0) SnakeHead.directionX = 1, SnakeHead.directionY = 0; // go right
        if (touche.keyCode === 40 && SnakeHead.directionY == 0) SnakeHead.directionY = 1, SnakeHead.directionX = 0; // go down
    }

    /**
     * Fait le Snake avancer de 1 dans la direction qu'il point
     */
    static move() {

        // seuelemt si le snake a plus de deux parties
        if (snakeList.length >= 2)
        {
            // donne a chaque partie du Snake la position de la partie en dessous dans la liste, donc plus proche de la tete, ce qui fait avancer le corp
            for(let i = snakeList.length; i > 1 ; i--) {
                let b = i - 2;
                snakeList[i - 1].x = snakeList[b].x;
                snakeList[i - 1].y = snakeList[b].y;
            }
        }

        // Avancement de la tete
        if (SnakeHead.directionX == -1) SnakeHead.x = (SnakeHead.x - SquareSize); // gauche
        if (SnakeHead.directionY == -1) SnakeHead.y = (SnakeHead.y - SquareSize); // haut
        if (SnakeHead.directionX == 1) SnakeHead.x = (SnakeHead.x + SquareSize); // droite
        if (SnakeHead.directionY == 1) SnakeHead.y = (SnakeHead.y + SquareSize); // bas


    }

    /**
     * Detect quand le Snake touche le bord du plateau et cree un message d'erreur
     */
    static checkForBorderCollision() {
        // si le Snake depasse les limites du plateau en Y
        if ((SnakeHead.y < 0) || (SnakeHead.y >= Boardsize)) {
            alert("You died");
        }
        // si le Snake depasse les limites du plateau en Y
        if ((SnakeHead.x < 0) || (SnakeHead.x >= Boardsize)) {
            alert("You died");
        }
    }

    /**
     * Detect quand le Snake touche son corp
     */
        static checkForSelfCollision() {
            for(let i = 1; i < snakeList.length; i++) {
                if ((SnakeHead.y == snakeList[i].y) && (SnakeHead.x == snakeList[i].x)) {
                    alert("You died");
                }
            }
        }

    /**
     * Ajout un nouveau bloc au Snake
     */
    static addNewSnakePart() {
        let newSnakeX = snakeList[snakeList.length -1].x;
        let newSnakeY = snakeList[snakeList.length -1].y;
        let newSnakeDirectionX = SnakeHead.directionX;
        let newSnakeDirectionY = SnakeHead.directionY;
        let newSnake = new Snake(snakeList.length, newSnakeX , newSnakeY, snakeList[snakeList.length -1].directionX, snakeList[snakeList.length -1].directionY)
        snakeList.push(newSnake)
    }
}
