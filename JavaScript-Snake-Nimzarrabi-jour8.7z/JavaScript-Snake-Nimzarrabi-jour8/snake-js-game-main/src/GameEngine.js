/**
 * ETML
 * Auteur:          Nima Zarrabi
 * Date:            07.11.2023
 * Description:     Jeu Snake
 * 
 * Version          1.7.0
 * Date:            9.1.2024
 */


import { Snake } from './Snake.js';
import { snakeList } from './Snake.js';
import { Food } from './Food.js';

// Declaration des variables

export let NumberOfSquare = 21;                     // doit etre un chiffre impaire
export let Boardsize = 630;                         // doit etre facilement divisible par NumberOfSquare
export let SquareSize = Boardsize / NumberOfSquare; // nombre de pixels par caree du plateau
let Point = 0;
let currentSnake;
const Speed = 250;
const Border = 10;
const Middle = (Border - (SquareSize / 2));
const canvas = document.querySelector('canvas');
const ctx = canvas.getContext('2d');

// Tete du Snake
export const SnakeHead = new Snake(0, Boardsize / 2, Boardsize / 2, 0, -1);
export const Apple = new Food(0, 0);


export class GameEngine {

    static gameInitiation() {
          
        // Dessine la grille de jeu
        ctx.fillStyle = 'black';
        ctx.fillRect(0, 0, Boardsize + (Border * 2), Boardsize + (Border * 2));

        ctx.fillStyle = 'white';
        ctx.fillRect(Border, Border, Boardsize, Boardsize);

        // dessine la tete du Snake
        ctx.fillStyle = 'green';
        ctx.fillRect(SnakeHead.x + Middle, SnakeHead.y + Middle, SquareSize, SquareSize);

        // detect les touches presse
        document.addEventListener('keydown', Snake.changeDirection);

        // ajout de la tete du Snake a la liste du Snake
        snakeList.push(SnakeHead)
        Food.spawnFood(Apple)
    }

    static startGame() {
        // interval auquel la boucle principale se repete
        setInterval(mainLoop, Speed);

        /**
         * Boucle principale
         */
        function mainLoop() {
            ctx.fillStyle = 'red';
            ctx.fillRect(Apple.x + Middle, Apple.y + Middle, SquareSize, SquareSize);

            Food.checkForAppleCollision(Apple);

            // Efface le Snake deriere lui
            currentSnake = snakeList[snakeList.length -1]
            ctx.fillStyle = 'white';
            ctx.fillRect(currentSnake.x + Middle, currentSnake.y + Middle, SquareSize, SquareSize);

            // le Snake avance de 1
            Snake.move();

            // dessine le Snake apres son avancement
            ctx.fillStyle = 'green';
            for(let i = 0; i < snakeList.length; i++) {
                ctx.fillRect(snakeList[i].x + Middle, snakeList[i].y + Middle, SquareSize, SquareSize);
            }
            // detect si le Snake touche un mur
            Snake.checkForBorderCollision();

            // detect si le Snake touche son corp
            Snake.checkForSelfCollision();
        }
    }
}
