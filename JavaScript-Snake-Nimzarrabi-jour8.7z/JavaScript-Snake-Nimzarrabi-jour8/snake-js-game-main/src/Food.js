/**
 * ETML
 * Auteur:          Nima Zarrabi
 * Date:            07.11.2023
 * Description:     Jeu Snake
 * 
 * Version          1.7.0
 * Date:            9.1.2024
 */

import { SnakeHead } from "./GameEngine.js";
import { Snake } from "./Snake.js";

import { NumberOfSquare } from './GameEngine.js';
import { SquareSize } from './GameEngine.js';

// points du joueur
let Point = 0;


export class Food {

    constructor(x, y) {
        this.x = x;             // Position X de la Pomme
        this.y = y;             // Position Y de la Pomme
    }

   /**
     * donne une valeur de position random a la pomme
     */
    static spawnFood(Apple) {
        Apple.x = (Math.floor(Math.random() * NumberOfSquare)) * (SquareSize) + SquareSize/2;
        Apple.y = (Math.floor(Math.random() * NumberOfSquare)) * (SquareSize) + SquareSize/2;
    }

   /**
     * met a jour l'elemet visuelle des points
     */
    static updatePoint() {
        const elementPoint = document.getElementById("PointID");
        elementPoint.innerHTML = Point;
    }

    /**
    * ajout un a la variable de point et appel la fonction updatePoint
    */
   static addPoint() {
    Point = Point +1;
    Food.updatePoint()
    }

    /**
    * check si le Snake touche la Pomme, si c'est le cas, ajouter un point, ajouter une nouvelle Pomme et ajouter une nouvelle part au Snake
    */
    static checkForAppleCollision(Apple) {
        if (SnakeHead.x == Apple.x && SnakeHead.y == Apple.y) {
            Food.addPoint()
            Food.spawnFood(Apple)
            Snake.addNewSnakePart()
        }
   }

}
